import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import label_binarize
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, f1_score, roc_auc_score,
    classification_report, confusion_matrix, roc_curve, auc
)
from sklearn.preprocessing import label_binarize

from pointnet_utils import PointNetEncoder, feature_transform_reguliarzer

# ─── Конфигурация ────────────────────────────────────────────────────────────────
NUM_CLASSES   = 5
BATCH_SIZE    = 32
EPOCHS        = 12
LEARNING_RATE = 0.001
CLASS_NAMES   = ['CAR','TRUCK','PEDESTRIAN','BIKE','BUS']
device        = torch.device("cuda" if torch.cuda.is_available() else "cpu")
PKL_PATH      = '/home/kirill/Variants/merged_df.pkl'
MODEL_PATH    = '/home/kirill/Variants/pt_ep_ep12.pth'

# ─── Dataset и collate_fn ─────────────────────────────────────────────────────────
class PointCloudDataset(Dataset):
    def __init__(self, df, num_points=1024):
        self.df = df.reset_index(drop=True)
        self.num_points = num_points
        self.label_map = {name:i for i,name in enumerate(CLASS_NAMES)}

    def __len__(self): return len(self.df)
    def __getitem__(self, idx):
        row   = self.df.iloc[idx]
        pts   = row['points'][:, :3].astype(np.float32)
        label = self.label_map[row['label']]
        if len(pts) >= self.num_points:
            choice = np.random.choice(len(pts), self.num_points, replace=False)
            pts = pts[choice]
        else:
            pad = np.zeros((self.num_points - len(pts),3),dtype=np.float32)
            pts = np.vstack([pts, pad])
        pts -= pts.mean(axis=0)
        m = np.linalg.norm(pts,axis=1).max()
        if m>1e-6: pts/=m
        return torch.from_numpy(pts), torch.tensor(label)

def collate_dynamic_pad(batch):
    pts_list, labels = zip(*batch)
    B = len(pts_list)
    max_pts = max(p.shape[0] for p in pts_list)
    pts_padded = torch.zeros((B, max_pts, 3), dtype=torch.float32)
    for i,p in enumerate(pts_list):
        pts_padded[i,:p.shape[0]] = p
    pts_padded = pts_padded.permute(0,2,1).to(device)
    labels     = torch.stack(labels).to(device)
    return pts_padded, labels

# ─── Модель ───────────────────────────────────────────────────────────────────────
class PointNetModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = PointNetEncoder(global_feat=True,
                                       feature_transform=True,
                                       channel=3)
        self.classifier = nn.Sequential(
            nn.Linear(1024,512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.4),
            nn.Linear(512,256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.5),
            nn.Linear(256,NUM_CLASSES)
        )
    def forward(self,x):
        x,_,_ = self.encoder(x)
        x = self.classifier(x)
        return F.log_softmax(x,dim=1)

def load_model(path):
    model = PointNetModel().to(device)
    ckpt  = torch.load(path, map_location=device)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()
    print(f"Loaded model from {path}")
    return model

# ─── Trainer ─────────────────────────────────────────────────────────────────────
class Trainer:
    def __init__(self, model, train_loader, val_loader, save_path='model.pth'):
        self.model = model.to(device)
        self.trl   = train_loader
        self.vll   = val_loader
        self.save_path = save_path

        # optimizer + loss
        self.opt = optim.Adam(self.model.parameters(), lr=LEARNING_RATE, weight_decay=1e-4)
        all_lbl = torch.cat([lbl for _,lbl in train_loader],dim=0)
        cnts    = torch.bincount(all_lbl.cpu(), minlength=NUM_CLASSES)
        wts     = 1.0/(cnts.float()+1e-6)
        self.crit = nn.CrossEntropyLoss(weight=wts.to(device))

        # пороги
        self.thr = np.full(NUM_CLASSES, 0.5, dtype=np.float32)

    def train(self):
        for ep in range(1, EPOCHS+1):
            self.model.train()
            L=0
            for x,y in self.trl:
                self.opt.zero_grad()
                out = self.model(x)
                loss= self.crit(out,y)
                loss.backward(); self.opt.step()
                L+=loss.item()
            print(f"[{ep}/{EPOCHS}] train_loss={L/len(self.trl):.4f}")
            cp = self.save_path.replace('.pth',f'_ep{ep}.pth')
            torch.save({
                'model_state_dict': self.model.state_dict(),
                'optimizer_state_dict': self.optimizer.state_dict()
            }, cp)
            print(" saved:",cp,"\n")
            # после каждой эпохи:
            self.find_optimal_thresholds(self.vll)
            self.validate(ep)
        print("Training finished.")

    def find_optimal_thresholds(self, loader):
        """Brute-force порогов 0.1..0.9 по F1"""
        self.model.eval()
        y_true, y_prob = [], []
        with torch.no_grad():
            for x,y in loader:
                out = self.model(x)
                probs = torch.exp(out).cpu().numpy()
                y_prob.append(probs)
                y_true.append(y.cpu().numpy())
        y_true = np.concatenate(y_true)
        y_prob = np.concatenate(y_prob)

        for c in range(NUM_CLASSES):
            # пропускаем класс, если нет меток
            if np.sum(y_true==c)==0:
                continue
            best, bt = 0,0.5
            for t in np.linspace(0.1,0.9,9):
                pred = (y_prob[:,c]>=t).astype(int)
                f1 = f1_score((y_true==c).astype(int), pred, zero_division=0)
                if f1>best:
                    best, bt = f1, t
            self.thr[c]=bt
        print(" thresholds:", np.round(self.thr,2))

    def validate(self):
        self.model.eval()
        y_true,y_pred,y_prob = [],[],[]
        with torch.no_grad():
            for x,y in self.vll:
                probs = torch.exp(self.model(x)).cpu().numpy()
                # binarize + argmax
                binp = (probs>=self.thr[None,:]).astype(int)
                y_pred.append(binp.argmax(1))
                y_prob.append(probs)
                y_true.append(y.cpu().numpy())
        y_true = np.concatenate(y_true)
        y_pred = np.concatenate(y_pred)
        y_prob = np.concatenate(y_prob)

        # основной отчёт
        acc   = accuracy_score(y_true, y_pred)
        f1m   = f1_score(y_true, y_pred, average='macro')
        print(f"→ VAL Epoch: acc={acc:.4f}, f1_macro={f1m:.4f}")

        # per-class F1
        per_class_f1 = f1_score(y_true, y_pred, average=None)
        for idx, f1 in enumerate(per_class_f1):
            print(f"F1-score для {CLASS_NAMES[idx]}: {f1:.4f}")

        # бинаризуем true-метки для ROC
        y_bin = label_binarize(y_true, classes=np.arange(NUM_CLASSES))
        # считаем AUC для каждого класса
        aucs = {}
        for i, cn in enumerate(CLASS_NAMES):
            if y_bin[:, i].sum() > 0:
                aucs[cn] = roc_auc_score(y_bin[:, i], y_prob[:, i])
        avg_auc = np.mean(list(aucs.values())) if aucs else np.nan
        print(f"Average AUC: {avg_auc:.4f}")
        for k, v in aucs.items():
            print(f"AUC {k}: {v:.4f}")

        # --- Построение ROC-кривых ---
        # Подготовка структуры для micro и macro
        fpr = dict()
        tpr = dict()
        roc_auc = dict()

        # Кривые по классам
        for i in range(NUM_CLASSES):
            if y_bin[:, i].sum() > 0:
                fpr[i], tpr[i], _ = roc_curve(y_bin[:, i], y_prob[:, i])
                roc_auc[i] = auc(fpr[i], tpr[i])

        # Micro-average
        fpr["micro"], tpr["micro"], _ = roc_curve(
            y_bin.ravel(), y_prob.ravel()
        )
        roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

        # Macro-average: объединяем все fpr
        all_fpr = np.unique(
            np.concatenate([fpr[i] for i in range(NUM_CLASSES) if i in fpr])
        )
        mean_tpr = np.zeros_like(all_fpr)
        for i in range(NUM_CLASSES):
            if i in fpr:
                mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
        mean_tpr /= len([i for i in range(NUM_CLASSES) if i in fpr])
        fpr["macro"] = all_fpr
        tpr["macro"] = mean_tpr
        roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

        # Рисуем
        plt.figure(figsize=(8, 6))
        # по классам
        for i, cn in enumerate(CLASS_NAMES):
            if i in fpr:
                plt.plot(fpr[i], tpr[i],
                        label=f'ROC {cn} (AUC = {roc_auc[i]:.2f})')

        # micro и macro
        plt.plot(fpr["micro"], tpr["micro"],
                label=f'micro-average (AUC = {roc_auc["micro"]:.2f})',
                linestyle=':', linewidth=2)
        plt.plot(fpr["macro"], tpr["macro"],
                label=f'macro-average (AUC = {roc_auc["macro"]:.2f})',
                linestyle='--', linewidth=2)

        plt.plot([0, 1], [0, 1], 'k--', lw=1)  # диагональ случайного угадывания
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC-кривые по классам')
        plt.legend(loc='lower right')
        plt.grid(True)
        plt.show()

def export_to_onnx(model, dataloader, output_path="model.onnx"):
    model.eval()
    for inputs, _ in dataloader:
        dummy_input = inputs
        break
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        input_names=['input'],
        output_names=['output'],
        dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}},
        opset_version=11
    )
    print(f"ONNX модель сохранена в {output_path}")

if __name__=='__main__':
    # датасет и стратификация
    df = pd.read_pickle(PKL_PATH)
    tr, vl = train_test_split(df,
        test_size=0.2, stratify=df['label'], random_state=42)

    tr_loader = DataLoader(PointCloudDataset(tr),
                   batch_size=BATCH_SIZE, shuffle=True,
                   collate_fn=collate_dynamic_pad)
    vl_loader = DataLoader(PointCloudDataset(vl),
                   batch_size=BATCH_SIZE, shuffle=False,
                   collate_fn=collate_dynamic_pad)

    model   = load_model(MODEL_PATH)
    trainer = Trainer(model, tr_loader, vl_loader)
    #trainer.train()
    trainer.validate()
    #export_to_onnx(model, tr_loader, output_path = "/home/kirill/Variants/Win/pt_ep_ep12.onnx")

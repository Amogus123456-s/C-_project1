import os
from typing import List
import rclpy
import cProfile
import numpy as np
import struct
import tkinter as tk
from tkinter import ttk
import time  
import torch
import torch.nn.functional as F
from sensor_msgs.msg import PointCloud2, PointField
import cupy as cp
#import cudf
#from cuml.cluster import DBSCAN as cuDBSCAN
import torch.nn as nn
from sklearn.linear_model import RANSACRegressor
from sklearn.cluster import DBSCAN
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
from visualization_msgs.msg import Marker, MarkerArray
from scipy.spatial import cKDTree
from geometry_msgs.msg import Point
from std_msgs.msg import Empty
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from pointnet_utils import PointNetEncoder, feature_transform_reguliarzer
from prunning import pruning
from kmeans_clustering import fast_kmeans
import math

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Конфигурация модели
CLASS_NAMES = ["CAR", "TRUCK", "PEDESTRIAN", "BIKE", "BUS"]
CLASS_COLORS = {
    "CAR": (1.0, 1.0, 1.0),      
    "TRUCK": (1.0, 0.0, 0.0),    
    "PEDESTRIAN": (0.0, 1.0, 0.0), 
    "BIKE": (1.0, 1.0, 0.0),     
    "BUS": (1.0, 0.0, 1.0)       
}
NUM_CLASSES = len(CLASS_NAMES)
MODEL_PATH = "/home/kirill/Variants/pt_ep_ep7.pth"
HOV = math.radians(120.0)     # 120° total → ±60° half‐angle :contentReference[oaicite:0]{index=0}
FOV = math.radians(25)     # 25° total  → ±12.5° half‐angle :contentReference[oaicite:1]{index=1}
MAX_RHO = 0.2 * 512

type_mappings = [(PointField.INT8, np.dtype('int8')),
                 (PointField.UINT8, np.dtype('uint8')),
                 (PointField.INT16, np.dtype('int16')),
                 (PointField.UINT16, np.dtype('uint16')),
                 (PointField.INT32, np.dtype('int32')),
                 (PointField.UINT32, np.dtype('uint32')),
                 (PointField.FLOAT32, np.dtype('float32')),
                 (PointField.FLOAT64, np.dtype('float64'))]

pftype_to_nptype = dict(type_mappings)
nptype_to_pftype = dict((nptype, pftype) for pftype, nptype in type_mappings)

def reset_rviz(self):
    reset_pub = self.create_publisher(Empty, '/rviz/reset', 100)
    reset_pub.publish(Empty())

class PointNet(nn.Module):
    def __init__(self, num_classes=NUM_CLASSES):
        super(PointNet, self).__init__()
        self.num_classes = num_classes
        self.encoder = PointNetEncoder(
            global_feat=True,
            feature_transform=True,
            channel=3
        )
        self.classifier = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes))
        
    def forward(self, x):
        x, trans, trans_feat = self.encoder(x)
        x = self.classifier(x)
        return F.log_softmax(x, dim=1), trans_feat
    
class CloudConverter:
    DUMMY_FIELD_PREFIX = '__'

    # mappings between PointField types and numpy types
    type_mappings = [(PointField.INT8, np.dtype('int8')), (PointField.UINT8, np.dtype('uint8')), (PointField.INT16, np.dtype('int16')),
                    (PointField.UINT16, np.dtype('uint16')), (PointField.INT32, np.dtype('int32')), (PointField.UINT32, np.dtype('uint32')),
                    (PointField.FLOAT32, np.dtype('float32')), (PointField.FLOAT64, np.dtype('float64'))]
    pftype_to_nptype = dict(type_mappings)
    nptype_to_pftype = dict((nptype, pftype) for pftype, nptype in type_mappings)
     # sizes (in bytes) of PointField types
    pftype_sizes = {PointField.INT8: 1, PointField.UINT8: 1, PointField.INT16: 2, PointField.UINT16: 2,
                    PointField.INT32: 4, PointField.UINT32: 4, PointField.FLOAT32: 4, PointField.FLOAT64: 8}
    
    @staticmethod
    def pointcloud2_to_array(cloud_msg, squeeze=True):
        ''' Converts a rospy PointCloud2 message to a numpy recordarray 
        
        Reshapes the returned array to have shape (height, width), even if the height is 1.
        The reason for using np.frombuffer rather than struct.unpack is speed... especially
        for large point clouds, this will be <much> faster.
        '''
        # construct a numpy record type equivalent to the point type of this cloud
        dtype_list = CloudConverter.fields_to_dtype(cloud_msg.fields, cloud_msg.point_step)

        # parse the cloud into an array
        cloud_arr = np.frombuffer(cloud_msg.data, dtype_list)

        # remove the dummy fields that were added
        cloud_arr = cloud_arr[
            [fname for fname, _type in dtype_list if not (fname[:len(CloudConverter.DUMMY_FIELD_PREFIX)] == CloudConverter.DUMMY_FIELD_PREFIX)]]
        
        if squeeze and cloud_msg.height == 1:
            return np.reshape(cloud_arr, (cloud_msg.width,))
        else:
            return np.reshape(cloud_arr, (cloud_msg.height, cloud_msg.width))

    @staticmethod
    def fields_to_dtype(fields, point_step):
        '''Convert a list of PointFields to a numpy record datatype.
        '''
        offset = 0
        np_dtype_list = []
        for f in fields:
            while offset < f.offset:
                # might be extra padding between fields
                np_dtype_list.append(('%s%d' % (CloudConverter.DUMMY_FIELD_PREFIX, offset), np.uint8))
                offset += 1

            dtype = CloudConverter.pftype_to_nptype[f.datatype]
            if f.count != 1:
                dtype = np.dtype((dtype, f.count))

            np_dtype_list.append((f.name, dtype))
            offset += CloudConverter.pftype_sizes[f.datatype] * f.count

        # might be extra padding between points
        while offset < point_step:
            np_dtype_list.append(('%s%d' % (CloudConverter.DUMMY_FIELD_PREFIX, offset), np.uint8))
            offset += 1
            
        return np_dtype_list

class LidarObjectDetector(Node):
    def __init__(self):
        super().__init__('lidar_object_detector')
        
        # Инициализация ROS
        self.subscription = self.create_subscription(
            PointCloud2, '/lidar_front/points', self.lidar_callback, 10)
        self.marker_pub = self.create_publisher(MarkerArray, 'visualization_marker_array', 10)
        #self.marker_clear_timer = self.create_timer(1.0, self.clear_all_markers)
        self.dbscan_eps = 0.8
        self.ransac_thresh = 0.05
        self.dbscan_min_samples = 300
        self.last_callback_time = 0.0
        self.min_callback_interval = 0.1  # 10 Гц
        self.voxel_size = 0.1
        self.max_points = 8000
        # Инициализация модели
        self.model = self.load_model()
        self.model.eval()
        
        # Состояние системы
        self.active_markers = []
        self.inference_times = []
        self.get_logger().info(f"Инициализация завершена на {device}")
        #self.dbscan = cuDBSCAN(eps=0.5, min_samples=300)
        
    def _voxel_downsample(self, points: np.ndarray) -> np.ndarray:
        """Простейший Voxel Grid: для каждого вокселя берём одну точку."""
        # переводим координаты в номер вокселя
        vox_idx = np.floor(points / self.voxel_size).astype(np.int32)
        # уникальные воксели + индекс первой точки в каждом
        _, unique_idx = np.unique(vox_idx, axis=0, return_index=True)
        return points[unique_idx]

    def fast_dbscan(self, points) -> list[np.ndarray]:
             
        N = points.shape[0]
        if N == 0:
            return []

        if N > self.max_points:
            points = self._voxel_downsample(points)

        # 2) собственно DBSCAN
        clustering = DBSCAN(
            eps=self.dbscan_eps,
            min_samples=self.dbscan_min_samples,
            algorithm="auto",
            metric='euclidean',
            n_jobs=-1
        ).fit(points)

        labels = clustering.labels_
        # формируем итоговые кластеры из downsampled-точек
        clusters_ds = [points[labels == lbl] for lbl in np.unique(labels) if lbl != -1]

        # Если нужно, можно маппить обратно в оригинал, но обычно достаточно кластеров ds
        return clusters_ds

    def load_model(self):
        """Загрузка обученной модели"""
        try:
            model = PointNet().to(device)
            checkpoint = torch.load(MODEL_PATH, map_location=device)
            model.load_state_dict(checkpoint['model_state_dict'])
            self.get_logger().info(f"Модель загружена из {MODEL_PATH}")
            return model
        except Exception as e:
            self.get_logger().error(f"Ошибка загрузки модели: {str(e)}")
            raise

    def preprocess_cluster(self, cluster: np.ndarray) -> torch.Tensor:
        """Обработка кластера точек: нормализация + ресемплинг/паддинг до 1024."""
        # 1) нормализация в единичную сферу
        cluster = cluster.astype(np.float32)
        cluster -= cluster.mean(axis=0, keepdims=True)
        norms = np.linalg.norm(cluster, axis=1)
        max_norm = norms.max() if norms.size>0 else 1.0
        if max_norm > 1e-6:
            cluster /= max_norm

        # 2) приведение к ровно 1024 точкам
        cluster = self.resample_points(cluster)

        # 3) в тензор [1, 3, 1024]
        pts = torch.from_numpy(cluster)                    # [1024,3]
        pts = pts.transpose(0,1).unsqueeze(0).to(device)   # [1,3,1024]
        return pts

    def resample_points(self, points: np.ndarray) -> np.ndarray:
        """Ресемплинг без дублирования; паддинг нулями."""
        N, D = points.shape  # D == 3
        if N >= 1024:
            # выбираем случайные 1024 индекса без возвращения
            idx = np.random.choice(N, 1024, replace=False)
            return points[idx]
        else:
            # паддинг нулями
            pad = np.zeros((1024 - N, D), dtype=points.dtype)
            return np.vstack([points, pad])

    def classify_object(self, cluster: np.ndarray):
        """Классификация одного кластера с замером времени."""
        try:
            inputs = self.preprocess_cluster(cluster)

            # замер инференса
            start = time.time()
            with torch.no_grad():
                logits, _ = self.model(inputs)
                # на всякий случай прогоняем через softmax
                probs = torch.softmax(logits, dim=1)
            # если на GPU, дождёмся вычислений
            if device.type=='cuda':
                torch.cuda.synchronize()
            elapsed = (time.time() - start) * 1000  # мс
            self.inference_times.append(elapsed)

            # извлекаем класс и вероятность
            max_prob, cls = probs.max(dim=1)
            return cls.item(), max_prob.item()

        except Exception as e:
            print(f"Ошибка классификации: {e}")
            return -1, 0.0

    def pointcloud2_to_numpy(self, msg, ground_threshold=0.0):
        """
        Высокопроизводительная конверсия PointCloud2 в Mx3 numpy array.
        """
        # Определяем структуру: три float32 (x,y,z) + padding
        point_dtype = np.dtype([
            ('x', np.float32),
            ('y', np.float32),
            ('z', np.float32),
            ('_pad', f'V{msg.point_step - 12}')
        ])
        # Интерпретируем данные как массив структур
        arr = np.frombuffer(msg.data, dtype=point_dtype)
        # Извлекаем только x,y,z
        xyz = np.stack([arr['x'], arr['y'], arr['z']], axis=1)
        # Фильтруем по ground_threshold
        mask = xyz[:,2] > ground_threshold
        return xyz[mask]
    
    def convert_to_model_input(self, msg):
        x = CloudConverter.pointcloud2_to_array(msg)
        nblocks, blocksize = x.shape
        if len(x) > 0:
            pointsize = len(x[0][0])
            pc_ = np.zeros(shape=(nblocks * blocksize, pointsize))
            x = np.reshape(x, (nblocks * blocksize,))
            pc_[:, 0] = x['x']
            pc_[:, 1] = x['y']
            pc_[:, 2] = x['z']
            pc_[:, 3] = x['intensity']
            return pc_
        return np.empty((0, 4))
    
    
    '''def fast_dbscan_gpu(self, points: np.ndarray) -> list[np.ndarray]:
        """
        GPU-кластеризация через cuML DBSCAN.
        Принимает на вход CPU-буфер (numpy), возвращает список кластеров numpy.
        """
        N = points.shape[0]
        if N == 0:
            return []

        # 1) Даунсэмплинг, если нужно
        if N > self.max_points:
            pts = self._voxel_downsample(points)
        else:
            pts = points

        # 2) Переносим данные в GPU-память
        # Переупакуем в cudf.DataFrame
        df = cudf.DataFrame({
            'x': cp.asarray(pts[:, 0]),
            'y': cp.asarray(pts[:, 1]),
            'z': cp.asarray(pts[:, 2])
        })

        # 3) Запускаем cuML-DBSCAN
        db = cuDBSCAN(eps=self.dbscan_eps,
                      min_samples=self.dbscan_min_samples,
                      metric='euclidean')
        labels_gpu = db.fit_predict(df)  # это cudf.Series на GPU

        # 4) Переносим метки обратно на CPU
        labels = labels_gpu.to_array().get()  # .get() превращает cupy->numpy

        # 5) Формируем кластеры
        clusters = []
        for lbl in np.unique(labels):
            if lbl == -1:
                continue
            mask = (labels == lbl)
            clusters.append(pts[mask])

        return clusters'''

    def ransac_dbscan_clustering(self, points, dbscan_eps=0.8, dbscan_min_samples=200, ransac_residual_threshold=0.1):
        """Удаление плоскости RANSAC + кластеризация DBSCAN."""
        if points.shape[0] == 0:
            return []

        # --- RANSAC для фильтрации земли (предполагаем, что ось Z — вверх) ---
        X = points[:, [0, 1]]  # x, y
        y = points[:, 2]       # z

        ransac = RANSACRegressor(residual_threshold=ransac_residual_threshold)
        try:
            ransac.fit(X, y)
            inlier_mask = ransac.inlier_mask_
            # Убираем точки, которые лежат на плоскости (земле)
            filtered_points = points[~inlier_mask]
        except Exception as e:
            print("RANSAC failed:", e)
            filtered_points = points  # fallback без фильтрации

        if filtered_points.shape[0] == 0:
            return []

        # --- DBSCAN на отфильтрованных точках ---
        clustering = DBSCAN(
            eps=dbscan_eps,
            min_samples=dbscan_min_samples,
            metric='euclidean',
            n_jobs=-1
        ).fit(filtered_points)

        labels = clustering.labels_
        clusters = [filtered_points[labels == lbl] for lbl in set(labels) if lbl != -1]

        return clusters
    
    def create_marker(self, min_xyz, max_xyz, marker_id, class_name, confidence):
        """Создание маркера с цветом класса"""
        marker = Marker()
        marker.header.frame_id = "lidar_front"
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "detected_objects"
        marker.id = marker_id
        marker.type = Marker.LINE_LIST
        marker.action = Marker.ADD
        marker.scale.x = 0.05
        
        # Цвет в зависимости от класса
        if class_name in CLASS_COLORS:
            r, g, b = CLASS_COLORS[class_name]
            marker.color.r = r
            marker.color.g = g
            marker.color.b = b
        else:
            marker.color.r = 0.0
            marker.color.g = 0.0
            marker.color.b = 0.0
            
        marker.color.a = 5.0

        # Построение bounding box
        corners = [
            [min_xyz[0], min_xyz[1], min_xyz[2]],
            [max_xyz[0], min_xyz[1], min_xyz[2]],
            [max_xyz[0], max_xyz[1], min_xyz[2]],
            [min_xyz[0], max_xyz[1], min_xyz[2]],
            [min_xyz[0], min_xyz[1], max_xyz[2]],
            [max_xyz[0], min_xyz[1], max_xyz[2]],
            [max_xyz[0], max_xyz[1], max_xyz[2]],
            [min_xyz[0], max_xyz[1], max_xyz[2]]
        ]
        
        edges = [(0,1),(1,2),(2,3),(3,0),
                 (4,5),(5,6),(6,7),(7,4),
                 (0,4),(1,5),(2,6),(3,7)]
        
        for e in edges:
            marker.points.append(self.create_point(corners[e[0]]))
            marker.points.append(self.create_point(corners[e[1]]))
            
        return marker

    def create_point(self, coords):
        """Создание Point сообщения"""
        p = Point()
        p.x, p.y, p.z = float(coords[0]), float(coords[1]), float(coords[2])
        return p

    def lidar_callback(self, msg):
        """Обработка входящих данных с batch‑классификацией кластеров"""     

        t1 = time.time()
        self.clear_all_markers()
        # 1) конвертируем PointCloud2 -> numpy
        pc_ = self.pointcloud2_to_numpy(msg)
        if pc_.size == 0:
            return
        t2 = (time.time() - t1) * 1000
        self.get_logger().info(f"Point to numpy array time: {t2:.1f} ms")
        self.get_logger().info(f"Pts before pruning: {pc_.shape[0]}")
        
        before_prune = pc_.shape[0]
        HOV=(120.0)/180.0*np.pi
        FOV=(25.0)/180.0*np.pi
        source_dim = pc_.shape[1]
        
        shift_ = 0.6
        pc_[:,2] -= shift_
        pc_ = pruning(
            pc=pc_,
            HOV=HOV,FOV=FOV,depthH=70,depthW=336,max_rho=0.2*512)
        pc_[:,2] += shift_
        pc_copy = pc_.copy()
        pc_ = pc_copy[:,:source_dim]
        after_prune = pc_.shape[0]
        print('##############################################')
        print(f'prunning coeff {100-after_prune/before_prune*100:.2f} before {before_prune} after {after_prune}')
        print('##############################################')

        self.get_logger().info(f"Pts after pruning: {pc_.shape[0]}")
        
        t_db = time.time()
        clusters = self.fast_dbscan(pc_)
        t_db = (time.time() - t_db) * 1000
        self.get_logger().info(f"[DEBUG] DBSCAN: {t_db:.1f} ms, raw clusters={len(clusters)}")
        self.get_logger().info(f"[DEBUG] Filtered clusters: {len(clusters)}")
        if not clusters:
            return

        # 4) пакетная подготовка ко входу PointNet: [N,3,1024]
        batch_pts = []
        for c in clusters:
            # эта функция нормализует + down/up‑sample до ровно 1024 точек
            # возвращает тензор [3,1024]
            batch_pts.append(self.preprocess_cluster(c).squeeze(0))
        batch = torch.stack(batch_pts, dim=0)  # [N,3,1024]

        # 5) единый прогон через модель
        with torch.no_grad():
            logits, _ = self.model(batch)
            probs = torch.softmax(logits, dim=1).cpu().numpy()  # [N, num_classes]

        # 6) строим маркеры
        marker_array = MarkerArray()
        for i, (cluster, prob) in enumerate(zip(clusters, probs)):
            cls = prob.argmax()
            conf = prob[cls]
            
            min_xyz = cluster.min(axis=0)
            max_xyz = cluster.max(axis=0)
            marker = self.create_marker(min_xyz, max_xyz, i, CLASS_NAMES[cls], conf)
            marker_array.markers.append(marker)

        self.marker_pub.publish(marker_array)
        self.active_markers = marker_array.markers
        self.log_performance(len(marker_array.markers), t1)

    def log_performance(self, num_clusters, ms):
        """Логирование производительности"""
        if num_clusters == 0:
            return
                    
        self.get_logger().info(f"[DEBUG] All time: {(time.time() - ms) * 1000:.1f}")        
        

    def clear_markers(self):
        """Очистка старых маркеров"""
        if not self.active_markers:
            return

        marker_array = MarkerArray()
        for marker in self.active_markers:
            marker.action = Marker.DELETE
            marker_array.markers.append(marker)

        self.marker_pub.publish(marker_array)
        self.active_markers = []

    def clear_all_markers(self):
        marker = Marker()
        marker.header.frame_id = ""  # Укажите ваш frame_id
        marker.action = Marker.DELETEALL
        marker_array = MarkerArray()
        marker_array.markers.append(marker)
        self.marker_pub.publish(marker_array)

class LidarGUI(tk.Tk):
    def __init__(self, ros_node: LidarObjectDetector):
        super().__init__()
        self.title("Lidar Clustering Parameters")
        self.geometry("400x280")
        self.ros_node = ros_node

        # Слайдеры
        self._make_slider("DBSCAN eps",        0.1,  5.0,  ros_node.dbscan_eps,         self.on_eps)
        self._make_slider("DBSCAN min_samples",1,    500,  ros_node.dbscan_min_samples, self.on_min_samples, integer=True)           
        # Статус
        self.status = ttk.Label(self, text="Ready")
        self.status.pack(pady=5)

        # Запускаем периодический вызов ROS spin_once()
        self.after(10, self._ros_spin)

    def _make_slider(self, title, frm, to, init, cmd, integer=False):
        frame = ttk.Frame(self); frame.pack(fill='x', padx=10, pady=4)
        ttk.Label(frame, text=title).pack(side='left')
        scale = ttk.Scale(frame, from_=frm, to=to, orient='horizontal',
                          command=lambda v: cmd(int(float(v)) if integer else float(v)))
        scale.set(init)
        scale.pack(fill='x', expand=True, side='left', padx=5)

    def on_eps(self, v):
        self.ros_node.dbscan_eps = v
        self.status['text'] = f"eps={v:.2f}"

    def on_min_samples(self, v):
        self.ros_node.dbscan_min_samples = int(v)
        self.status['text'] = f"min_samples={v}"

    def _ros_spin(self):
        """Вызываем spin_once, чтобы принимать сообщения в фоне."""
        rclpy.spin_once(self.ros_node, timeout_sec=0)
        self.after(10, self._ros_spin)

def main():
    rclpy.init()
    node = LidarObjectDetector()

    # Запускаем GUI — она сама будет дергать spin_once()
    app = LidarGUI(node)
    app.mainloop()

    # При выходе из GUI корректно останавливаем ROS
    node.get_logger().info("Shutting down...")
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()